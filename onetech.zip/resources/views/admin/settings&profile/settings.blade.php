@extends('admin.dashboardPart.mainBody')
@section('mainBody')

@include('admin.settings&profile.updatePassword')

@endsection