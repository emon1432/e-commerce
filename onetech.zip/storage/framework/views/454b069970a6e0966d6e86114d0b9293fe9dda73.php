<?php $__env->startSection('mainBody'); ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/styles/contact_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/styles/contact_responsive.css')); ?>">
<div class="contact_form">
    <div class="container">
        <div class="row">
            <div class="col-lg-5 offset-lg-1">
                <div class="contact_form_container" style="border: 1px solid grey; padding:20px; border-radius: 25px;">
                    <div class="contact_form_title text-center">Sign In</div>

                    <form method="POST" action="<?php echo e(route('login')); ?>" id="contact_form">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control" placeholder="Enter your email" required autofocus>
                        </div><!-- form-group -->
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="Enter your password" required autocomplete="current-password" style="margin-bottom: 10px;">
                            <?php if(Route::has('password.request')): ?>
                            <a href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
                            <?php endif; ?>
                        </div><!-- form-group -->
                        <button type="submit" class="btn btn-info">Sign In</button>
                    </form>
                    <br>
                    <button type="submit" class="btn btn-primary btn-block"><i class="fab fa-facebook-square"></i> Login with Facebook</button>
                    <button type="submit" class="btn btn-danger btn-block"><i class="fab fa-google"></i> Login with Google</button>
                </div>
                <br><br><br>
            </div>

            <div class="col-lg-5 offset-lg-1" style="border: 1px solid grey; padding:20px; border-radius: 25px;">
                <div class="contact_form_container">
                    <div class="contact_form_title text-center">Sign Up</div>

                    <form method="POST" action="<?php echo e(route('register')); ?>" id="contact_form">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="name">Full Name</label>
                            <input type="text" class="form-control" name="name" placeholder="Enter your fullname" required autofocus autocomplete="name">
                        </div><!-- form-group -->
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                        </div><!-- form-group -->
                        <div class="form-group">
                            <label for="password">Password</label>
                            <input type="password" class="form-control" name="password" required autocomplete="new-password" placeholder="Enter Password">
                        </div><!-- form-group -->
                        <div class="form-group">
                            <label for="password_confirmation">Confirm Password</label>
                            <input type="password" class="form-control" name="password_confirmation" required autocomplete="new-password" placeholder="Confirm Password">
                        </div><!-- form-group -->
                        <div class="form-group">
                            <!-- <label for="user_role">User Role</label> -->
                            <input type="hidden" class="form-control" name="user_role" value="0">
                        </div><!-- form-group -->
                        <?php if(Laravel\Jetstream\Jetstream::hasTermsAndPrivacyPolicyFeature()): ?>
                        <div class="mt-4">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['for' => 'terms']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'terms']); ?>
                                <div class="flex items-center">

                                    <div class="ml-2">
                                        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.checkbox','data' => ['name' => 'terms','id' => 'terms']]); ?>
<?php $component->withName('jet-checkbox'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['name' => 'terms','id' => 'terms']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                                        <?php echo __('I agree to the :terms_of_service and :privacy_policy', [
                                        'terms_of_service' => '<a target="_blank" href="'.route('terms.show').'" class="underline text-sm text-gray-600 hover:text-gray-900">'.__('Terms').'</a>',
                                        'privacy_policy' => '<a target="_blank" href="'.route('policy.show').'" class="underline text-sm text-gray-600 hover:text-gray-900">'.__('Privacy Policy').'</a>',
                                        ]); ?>

                                    </div>
                                </div>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                        <?php endif; ?>
                        <button type="submit" class="btn btn-info">Sign Up</button>
                    </form>

                </div>
            </div>
        </div>
    </div>
    <div class="panel"></div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Laravel/e-commerce/resources/views/main/clientsPart/register&login.blade.php ENDPATH**/ ?>