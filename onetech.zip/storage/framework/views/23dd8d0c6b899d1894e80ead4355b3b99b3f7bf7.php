<!DOCTYPE html>
<html lang="en">

<head>
	<title>OneTech</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="description" content="OneTech shop project">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/styles/bootstrap4/bootstrap.min.css')); ?>">
	<link href="<?php echo e(asset('frontend/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css')); ?>" rel="stylesheet" type="text/css">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/plugins/OwlCarousel2-2.2.1/owl.carousel.css')); ?> ">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/plugins/OwlCarousel2-2.2.1/owl.theme.default.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/plugins/OwlCarousel2-2.2.1/animate.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/plugins/slick-1.8.0/slick.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/styles/main_styles.css')); ?>">
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend/styles/responsive.css')); ?>">
	<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.css" />
	<?php if(basename($_SERVER['PHP_SELF']) != 'index.php'): ?>
	<style>
		.cat_menu_container ul {
			visibility: hidden;
			opacity: 0;
		}
	</style>
	<?php endif; ?>
</head>

<body>
	<div class="super_container">

		<?php echo $__env->make('main.clientsPart.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


		<?php echo $__env->yieldContent('mainBody'); ?>

		<?php echo $__env->make('main.clientsPart.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>

	<script src="<?php echo e(asset('frontend/js/jquery-3.3.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/styles/bootstrap4/popper.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/styles/bootstrap4/bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/greensock/TweenMax.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/greensock/TimelineMax.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/scrollmagic/ScrollMagic.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/greensock/animation.gsap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/greensock/ScrollToPlugin.min.jsplugins/greensock/ScrollToPlugin.min.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/OwlCarousel2-2.2.1/owl.carousel.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/slick-1.8.0/slick.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/plugins/easing/easing.js')); ?>"></script>
	<script src="<?php echo e(asset('frontend/js/custom.js')); ?>"></script>

	<script src="<?php echo e(asset('https://unpkg.com/sweetalert@2.1.2/dist/sweetalert.min.js')); ?>"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


	<script>
		$(document).on("click", "#delete", function(e) {
			e.preventDefault();
			var link = $(this).attr("href");
			swal({
					title: "Are you want to delete?",
					text: "Once Delete, This will be Permanently Delete!",
					icon: "warning",
					buttons: true,
					dangerMode: true,
				})
				.then((willDelete) => {
					if (willDelete) {
						window.location.href = link;
					} else {
						swal("Safe Data!");
					}
				});
		});
	</script>

	<script type="text/javascript">
		<?php if(Session::has('message')): ?>
		var type = "<?php echo e(Session::get('alert-type','info')); ?>"
		switch (type) {
			case 'info':
				toastr.info("<?php echo e(Session::get('message')); ?>");
				break;

			case 'success':
				toastr.success("<?php echo e(Session::get('message')); ?>");
				break;

			case 'warning':
				toastr.warning("<?php echo e(Session::get('message')); ?>");
				break;

			case 'error':
				toastr.error("<?php echo e(Session::get('message')); ?>");
				break;
		}
		<?php endif; ?>
	</script>
	




</body>

</html><?php /**PATH /opt/lampp/htdocs/Laravel/e-commerce/resources/views/main/index.blade.php ENDPATH**/ ?>